package com.mitocode.dao;

import java.util.List;
import java.util.concurrent.CompletableFuture;

public interface IFilaDAO {
	
	CompletableFuture<List<String>> getFilasAsync();
	List<String> getFilas();	
}
